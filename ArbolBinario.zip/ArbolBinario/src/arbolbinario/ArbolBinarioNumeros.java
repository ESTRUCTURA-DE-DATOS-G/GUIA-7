package arbolbinario;

import java.util.LinkedList;
import java.util.Queue;

public class ArbolBinarioNumeros {

    private NodoNumeros raiz;
    private String preOrden;
    private String postOrden;
    private String inOrden;
    private String busquedaAmplitud;

    private int alturaArbol;
    private int alturaNodo;

    public ArbolBinarioNumeros() {
        this.raiz = null;
    }

    public void insertarNodo(int valor) {
        if (raiz == null) {
            raiz = new NodoNumeros(valor);
        } else {
            raiz.insertarNumeros(valor);
        }

    }

    public void recorridoPreOrden() {
        preOrden = "";
        PreOrden(raiz);
    }

    //raíz -> hijo izquierdo -> hijo derecho
    private void PreOrden(NodoNumeros nodo) {

        if (nodo == null) {
            return;
        }
        preOrden = preOrden + " " + nodo.getDato();
        PreOrden(nodo.getNodoIzq());
        PreOrden(nodo.getNodoDer());

    }

    public void recorridoInOrden() {
        inOrden = "";
        InOrden(raiz);

    }

    //hijo izquierdo -> raíz -> hijo derecho
    public void InOrden(NodoNumeros nodo) {
        if (nodo == null) {
            return;
        }
        InOrden(nodo.getNodoIzq());
        inOrden = inOrden + " " + nodo.getDato();
        InOrden(nodo.getNodoDer());

    }

    //hijo izquierdo -> hijo derecho -> raíz
    public void recorridoPostOrden() {
        postOrden = "";
        PostOrden(raiz);
    }

    public void PostOrden(NodoNumeros nodo) {
        if (nodo == null) {

        } else {
            PostOrden(nodo.getNodoIzq());
            PostOrden(nodo.getNodoDer());
            postOrden = postOrden + " " + nodo.getDato();
        }
    }

    public boolean AlturaNodo(int nodoB) {
        alturaNodo = 1;
        NodoNumeros buscar = raiz;

        while (buscar != null) {
            if (nodoB == buscar.getDato()) {
                return true;
            } else if (nodoB > buscar.getDato()) {
                buscar = buscar.getNodoDer();
                alturaNodo = alturaNodo + 1;
            } else {
                buscar = buscar.getNodoIzq();
                alturaNodo = alturaNodo + 1;
            }
        }
        return false;
    }

    public void AlturaArb(NodoNumeros arb, int nivel) {
        if (arb != null) {
            AlturaArb(arb.getNodoIzq(), nivel + 1);
            if (nivel > alturaArbol) {
                alturaArbol = nivel;
            }
            AlturaArb(arb.getNodoDer(), nivel + 1);

        }

    }

    public void AlturaArbol() {
        alturaArbol = 0;
        AlturaArb(raiz, 1);

    }

    public void BusquedaAmplitud() {
        busquedaAmplitud = "";
        busquedaPorAmplitud(raiz);
    }

    public void busquedaPorAmplitud(NodoNumeros nodo) {
        if (nodo == null) {
            return;
        }

        Queue<NodoNumeros> cola = new LinkedList<>();
        cola.add(nodo);

        while (!cola.isEmpty()) {

            NodoNumeros nodoActual = cola.poll();
            busquedaAmplitud = busquedaAmplitud + nodoActual.getDato() + " ";

            if (nodoActual.getNodoIzq() != null) {
                cola.add(nodoActual.getNodoIzq());
            }
            if (nodoActual.getNodoDer() != null) {
                cola.add(nodoActual.getNodoDer());
            }
        }
    }

    public String getBusquedaAmplitud() {
        return busquedaAmplitud;
    }

    public String getPreOrden() {
        return preOrden;
    }

    public String getPostOrden() {
        return postOrden;
    }

    public String getInOrden() {
        return inOrden;
    }

    public int getAlturaArbol() {
        return alturaArbol;
    }

    public int getAlturaNodo() {
        return alturaNodo;
    }

    public NodoNumeros getRaiz() {
        return raiz;
    }

}
