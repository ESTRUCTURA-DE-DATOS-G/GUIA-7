package arbolbinario;

import java.util.LinkedList;
import java.util.Queue;

public class ArbolBinarioLetras {

    private NodoLetras raiz;
    private String preOrden;
    private String busquedaAmplitud;

    private String postOrden;
    private String inOrden;
    private int alturaNodo;
    private int alturaArbol;

    public ArbolBinarioLetras() {
        this.raiz = null;
    }

    public void insertarNodo(char valor) {
        if (raiz == null) {
            raiz = new NodoLetras(valor);
        } else {
            raiz.insertarLetras(valor);
        }

    }

    public void recorridoPreOrden() {
        preOrden = "";
        PreOrden(raiz);
    }

    //raíz -> hijo izquierdo -> hijo derecho
    private void PreOrden(NodoLetras nodo) {

        if (nodo == null) {
            return;
        }
        preOrden = preOrden + " " + nodo.getDato();
        PreOrden(nodo.getNodoIzq());
        PreOrden(nodo.getNodoDer());

    }

    public void recorridoInOrden() {
        inOrden = "";
        InOrden(raiz);

    }

    //hijo izquierdo -> raíz -> hijo derecho
    public void InOrden(NodoLetras nodo) {
        if (nodo == null) {
            return;
        }
        InOrden(nodo.getNodoIzq());
        inOrden = inOrden + " " + nodo.getDato();
        InOrden(nodo.getNodoDer());

    }

    public void recorridoPostOrden() {
        postOrden = "";
        PostOrden(raiz);
    }

    public void PostOrden(NodoLetras nodo) {
        if (nodo == null) {

        } else {
            PostOrden(nodo.getNodoIzq());
            PostOrden(nodo.getNodoDer());
            postOrden = postOrden + " " + nodo.getDato();
        }
    }

    public boolean AlturaNodo(char nodoB) {
        alturaNodo = 1;
        NodoLetras buscar = raiz;

        while (buscar != null) {
            if (nodoB == buscar.getDato()) {
                return true;
            } else if (nodoB > buscar.getDato()) {
                buscar = buscar.getNodoDer();
                alturaNodo = alturaNodo + 1;
            } else {
                buscar = buscar.getNodoIzq();
                alturaNodo = alturaNodo + 1;
            }
        }
        return false;
    }

    public void AlturaArb(NodoLetras arb, int nivel) {
        if (arb != null) {
            AlturaArb(arb.getNodoIzq(), nivel + 1);
            if (nivel > alturaArbol) {
                alturaArbol = nivel;
            }
            AlturaArb(arb.getNodoDer(), nivel + 1);

        }

    }
    
    public void AlturaArbol() {
        alturaArbol = 0;
        AlturaArb(raiz, 1);
    }
    
    public void BusquedaAmplitud() {
        busquedaAmplitud = "";
        busquedaPorAmplitud(raiz);
    }

    public void busquedaPorAmplitud(NodoLetras nodo) {
        if (nodo == null) {
            return;
        }

        Queue<NodoLetras> cola = new LinkedList<>();
        cola.add(nodo);

        while (!cola.isEmpty()) {
            NodoLetras nodoActual = cola.poll();
            busquedaAmplitud = busquedaAmplitud + nodoActual.getDato() + " ";

            if (nodoActual.getNodoIzq() != null) {
                cola.add(nodoActual.getNodoIzq());
            }
            if (nodoActual.getNodoDer() != null) {
                cola.add(nodoActual.getNodoDer());
            }
        }
    }

    

    public String getBusquedaAmplitud() {
        return busquedaAmplitud;
    }

    public int getAlturaArbol() {
        return alturaArbol;
    }

    public int getAlturaNodo() {
        return alturaNodo;
    }

    public String getPreOrden() {
        return preOrden;
    }

    public String getPostOrden() {
        return postOrden;
    }

    public String getInOrden() {
        return inOrden;
    }

    public NodoLetras getRaiz() {
        return raiz;
    }
}
