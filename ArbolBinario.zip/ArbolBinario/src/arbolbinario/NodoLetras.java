
package arbolbinario;


public class NodoLetras {
    private char dato;
    private NodoLetras nodoIzq;
    private NodoLetras nodoDer;

    public char getDato() {
        return dato;
    }

    public NodoLetras getNodoIzq() {
        return nodoIzq;
    }

    public NodoLetras getNodoDer() {
        return nodoDer;
    }

   

    public NodoLetras() {

    }

    public NodoLetras(char datoNodo) {
        this.dato = datoNodo;
        nodoIzq = null;
        nodoDer = null;
    }

    public void insertarLetras(char valor) {

        if (valor <= dato) {
            if (nodoIzq == null) {
                nodoIzq = new NodoLetras(valor);
            } else {
                nodoIzq.insertarLetras(valor);
            }
        } else if (valor > dato) {
            if (nodoDer == null) {
                nodoDer = new NodoLetras(valor);
            } else {
                nodoDer.insertarLetras(valor);
            }

        }

    }
    
    public int NodosCompletos (NodoLetras n){
        if (n==null) {
           return 0; 
        }else{
            if (n.getNodoIzq()!=null&&n.getNodoDer()!=null) {
                return NodosCompletos(n.getNodoIzq())+NodosCompletos(n.getNodoDer())+1;
            }
        }
        return 0;
    }
    
    
}
