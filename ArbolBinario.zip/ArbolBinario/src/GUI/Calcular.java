package GUI;

import arbolbinario.ArbolBinarioLetras;
import arbolbinario.ArbolBinarioNumeros;
import javax.swing.JOptionPane;

public class Calcular extends javax.swing.JFrame {

    ArbolBinarioNumeros arbolNumeros;
    ArbolBinarioLetras arbolLetras;

    public Calcular(ArbolBinarioNumeros ArbolNumeros, ArbolBinarioLetras ArbolLetras) {
        initComponents();
        this.setLocationRelativeTo(this);
        arbolNumeros = ArbolNumeros;
        arbolLetras = ArbolLetras;
        AlturaArbol();
        BusquedaAmplitud();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        gradoArbolNumeros = new javax.swing.JLabel();
        gradoArbolLetras = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        alturaArbolNumeros = new javax.swing.JLabel();
        AlturaArbolLetras = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        btnNivelNumeros = new javax.swing.JButton();
        btnNivelLetras = new javax.swing.JButton();
        btnCrearNodo1 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        numerosAmplitud = new javax.swing.JLabel();
        letrasAmplitud = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 30)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Calcular");

        jLabel9.setFont(new java.awt.Font("Malgun Gothic Semilight", 1, 14)); // NOI18N
        jLabel9.setText("Grado");

        jLabel10.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 14)); // NOI18N
        jLabel10.setText("Arbol Letras");

        jLabel11.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 14)); // NOI18N
        jLabel11.setText("Arbol Numeros");

        gradoArbolNumeros.setText("2");

        gradoArbolLetras.setText("2");

        jLabel12.setFont(new java.awt.Font("Malgun Gothic Semilight", 1, 14)); // NOI18N
        jLabel12.setText("Altura");

        jLabel13.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 14)); // NOI18N
        jLabel13.setText("Arbol Numeros");

        alturaArbolNumeros.setText("0");

        AlturaArbolLetras.setText("0");

        jLabel14.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 14)); // NOI18N
        jLabel14.setText("Arbol Letras");

        jLabel15.setFont(new java.awt.Font("Malgun Gothic Semilight", 1, 14)); // NOI18N
        jLabel15.setText("Calcular el nivel, dado un nodo");

        jLabel16.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 14)); // NOI18N
        jLabel16.setText("Arbol Numeros");

        jLabel17.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 14)); // NOI18N
        jLabel17.setText("Arbol Letras");

        btnNivelNumeros.setBackground(new java.awt.Color(0, 0, 0));
        btnNivelNumeros.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 14)); // NOI18N
        btnNivelNumeros.setForeground(new java.awt.Color(255, 255, 255));
        btnNivelNumeros.setText("Calcular");
        btnNivelNumeros.setBorderPainted(false);
        btnNivelNumeros.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnNivelNumeros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNivelNumerosActionPerformed(evt);
            }
        });

        btnNivelLetras.setBackground(new java.awt.Color(0, 0, 0));
        btnNivelLetras.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 14)); // NOI18N
        btnNivelLetras.setForeground(new java.awt.Color(255, 255, 255));
        btnNivelLetras.setText("Calcular");
        btnNivelLetras.setBorderPainted(false);
        btnNivelLetras.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnNivelLetras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNivelLetrasActionPerformed(evt);
            }
        });

        btnCrearNodo1.setBackground(new java.awt.Color(0, 0, 0));
        btnCrearNodo1.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 14)); // NOI18N
        btnCrearNodo1.setForeground(new java.awt.Color(255, 255, 255));
        btnCrearNodo1.setText("Cerrar");
        btnCrearNodo1.setBorderPainted(false);
        btnCrearNodo1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnCrearNodo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearNodo1ActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 14)); // NOI18N
        jLabel18.setText("Arbol Letras:");

        jLabel19.setFont(new java.awt.Font("Malgun Gothic Semilight", 1, 14)); // NOI18N
        jLabel19.setText("Búsqueda en Amplitud");

        jLabel20.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 14)); // NOI18N
        jLabel20.setText("Arbol Numeros:");

        numerosAmplitud.setText("0");

        letrasAmplitud.setText("0");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(107, 107, 107)
                .addComponent(gradoArbolNumeros)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(gradoArbolLetras)
                .addGap(127, 127, 127))
            .addGroup(layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(71, 71, 71)
                        .addComponent(jLabel10)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel16)
                                    .addGap(71, 71, 71)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(6, 6, 6)
                                            .addComponent(btnNivelLetras))
                                        .addComponent(jLabel17)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(20, 20, 20)
                                                .addComponent(btnNivelNumeros))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(19, 19, 19)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                            .addComponent(jLabel18)
                                                            .addComponent(jLabel20))
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(numerosAmplitud)
                                                            .addComponent(letrasAmplitud)))
                                                    .addComponent(jLabel15))))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addComponent(jLabel19))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(37, 37, 37)
                                                .addComponent(alturaArbolNumeros)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(AlturaArbolLetras)))
                                        .addGap(32, 32, 32))))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel13)
                                    .addGap(71, 71, 71)
                                    .addComponent(jLabel14))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(109, 109, 109)
                                    .addComponent(jLabel12))))
                        .addContainerGap(96, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(176, 176, 176)
                        .addComponent(jLabel9))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(155, 155, 155)
                        .addComponent(btnCrearNodo1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(gradoArbolNumeros)
                    .addComponent(gradoArbolLetras))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(alturaArbolNumeros)
                    .addComponent(AlturaArbolLetras))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel19)
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(numerosAmplitud))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(letrasAmplitud))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNivelNumeros)
                    .addComponent(btnNivelLetras))
                .addGap(27, 27, 27)
                .addComponent(btnCrearNodo1)
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCrearNodo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearNodo1ActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnCrearNodo1ActionPerformed

    private void btnNivelNumerosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNivelNumerosActionPerformed
        int nodoB = 0;
        nodoB = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el nodo para "
                + "buscar su nivel: ", "Nivel Nodo", 1));
        if (arbolNumeros.AlturaNodo(nodoB)) {

            JOptionPane.showMessageDialog(null, "La altura del nodo " + nodoB
                    + " es: " + arbolNumeros.getAlturaNodo(), "Nivel Nodo", 1);
        } else {
            JOptionPane.showMessageDialog(null, "No existe el nodo", "Nivel Nodo", 0);
        }


    }//GEN-LAST:event_btnNivelNumerosActionPerformed

    private void btnNivelLetrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNivelLetrasActionPerformed
        String aux = "";
        char nodoB;

        aux = JOptionPane.showInputDialog(null, "Ingrese el nodo para "
                + "buscar su nivel: ", "Nivel Nodo", 1);

        nodoB = aux.charAt(0);
        if (arbolLetras.AlturaNodo(nodoB)) {

            JOptionPane.showMessageDialog(null, "La altura del nodo " + nodoB
                    + " es: " + arbolLetras.getAlturaNodo(), "Nivel Nodo", 1);
        } else {
            JOptionPane.showMessageDialog(null, "No existe el nodo", "Nivel Nodo", 0);
        }
    }//GEN-LAST:event_btnNivelLetrasActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AlturaArbolLetras;
    private javax.swing.JLabel alturaArbolNumeros;
    private javax.swing.JButton btnCrearNodo1;
    private javax.swing.JButton btnNivelLetras;
    private javax.swing.JButton btnNivelNumeros;
    private javax.swing.JLabel gradoArbolLetras;
    private javax.swing.JLabel gradoArbolNumeros;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel letrasAmplitud;
    private javax.swing.JLabel numerosAmplitud;
    // End of variables declaration//GEN-END:variables

    private void AlturaArbol() {
        arbolNumeros.AlturaArbol();
        alturaArbolNumeros.setText(String.valueOf(arbolNumeros.getAlturaArbol()));

        arbolLetras.AlturaArbol();
        AlturaArbolLetras.setText(String.valueOf(arbolLetras.getAlturaArbol()));

    }
    
    private void BusquedaAmplitud(){
        arbolNumeros.BusquedaAmplitud();
        numerosAmplitud.setText(arbolNumeros.getBusquedaAmplitud());
        
        arbolLetras.BusquedaAmplitud();
        letrasAmplitud.setText(arbolLetras.getBusquedaAmplitud());
    
    }
}
