package GUI;

import arbolbinario.ArbolBinarioNumeros;
import arbolbinario.NodoNumeros;
import java.awt.Graphics;

public class DibujarNumeros extends javax.swing.JFrame {

    private ArbolBinarioNumeros arbol;
    private int diametro = 30;
    private int radio = diametro / 2;
    private int ancho = 50;

    public DibujarNumeros() {
        
        initComponents();
        this.setLocationRelativeTo(this);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
    
    
    

    public void setArbol(ArbolBinarioNumeros arbol) {
        this.arbol = arbol;
        repaint();
    }
    
    @Override
    public void paint(Graphics g) {
        super.paint(g); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
        pintar(g, getWidth() / 2, 20, arbol.getRaiz());
    }
    
    private void pintar(Graphics g, int x, int y, NodoNumeros n) {
        y=y+15;
        
        if (n == null) {

        } else {
            int extra = n.NodosCompletos(n) * (ancho / 2)-10;
            g.drawOval(x, y, diametro, diametro);
            g.drawString(String.valueOf(n.getDato()), x + 12, y + 18);
            if (n.getNodoIzq() != null) {
                g.drawLine(x + radio, y + radio+15, x - ancho - extra + radio, y + ancho + radio);
            }
            if (n.getNodoDer() != null) {
                g.drawLine(x + radio, y + radio+15, x + ancho + extra + radio, y + ancho + radio);
            }
            pintar(g, x - ancho - extra, y + ancho, n.getNodoIzq());
            pintar(g, x + ancho + extra, y + ancho, n.getNodoDer());
        }
    }


}
