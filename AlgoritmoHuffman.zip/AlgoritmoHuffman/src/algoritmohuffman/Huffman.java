package algoritmohuffman;

import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;

public class Huffman {

    private Nodo raiz;
    private final String texto;
    private Map<Character, Integer> charFrecuencias;
    private final Map<Character, String> huffmanCodigos;

    public Huffman(String texto) {
        this.texto = texto;
        LlenarCharFrecuenciasMap();
        huffmanCodigos = new HashMap<>();
    }

    private void LlenarCharFrecuenciasMap() {
        charFrecuencias = new HashMap<>();
        for (char character : texto.toCharArray()) {
            Integer integer = charFrecuencias.get(character);
            charFrecuencias.put(character, integer != null ? integer + 1 : 1);
        }
    }

    public String Decodificar() {
        Queue<Nodo> queue = new PriorityQueue<>();
        charFrecuencias.forEach((character, frecuencia)
                -> queue.add(new Hoja(character, frecuencia))
        );
        while (queue.size() > 1) {
            queue.add(new Nodo(queue.poll(), queue.poll()));
        }
        generarHuffmanCodigos(raiz = queue.poll(), "");
        return getDecodificarTexto();
    }

    private void generarHuffmanCodigos(Nodo nodo, String codigo) {
        if (nodo instanceof Hoja) {
            huffmanCodigos.put(((Hoja) nodo).getCharacter(), codigo);
            return;
        }
        generarHuffmanCodigos(nodo.getNodoIzquierdo(), codigo.concat("0"));
        generarHuffmanCodigos(nodo.getNodoDerecho(), codigo.concat("1"));
    }
    
    private String getDecodificarTexto(){
        StringBuilder sb = new StringBuilder();
        for(char character : texto.toCharArray()){
            sb.append(huffmanCodigos.get(character));
        }
        return sb.toString();
    }
    
    public String Decodificar(String decodificarTexto){
        StringBuilder sb = new StringBuilder();
        Nodo actual = raiz;
        for(char character : decodificarTexto.toCharArray()){
            actual = character == '0' ? actual.getNodoIzquierdo() : actual.getNodoDerecho();
            if(actual instanceof Hoja hoja){
                sb.append(hoja.getCharacter());
                actual = raiz;
            }
        }
        return sb.toString();
    }
    
    public void imprimirCodigos(){
        huffmanCodigos.forEach((character, codigo) ->
                                System.out.println(character + ": " + codigo)
        );
    }
}
