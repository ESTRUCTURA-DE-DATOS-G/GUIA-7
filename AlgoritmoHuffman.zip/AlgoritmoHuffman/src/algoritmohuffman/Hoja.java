package algoritmohuffman;

public class Hoja extends Nodo {
    
    private final char character;

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + this.character;
        return hash;
    }

    public char getCharacter() {
        return character;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Hoja other = (Hoja) obj;
        return this.character == other.character;
    }
    
    public Hoja(char character, int frecuencia){
        super(frecuencia);
        this.character = character;
    }
}
