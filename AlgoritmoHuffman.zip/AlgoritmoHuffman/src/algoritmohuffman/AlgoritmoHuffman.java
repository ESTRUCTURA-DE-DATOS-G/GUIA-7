package algoritmohuffman;

public class AlgoritmoHuffman {

    public static void main(String[] args) {
        Huffman huffman = new Huffman("Echeeee");

        String textoDecodificado = huffman.Decodificar();
        System.out.println(textoDecodificado);

        huffman.imprimirCodigos();

        String textoOriginal = huffman.Decodificar(textoDecodificado);
        System.out.println(textoOriginal);

    }
}
