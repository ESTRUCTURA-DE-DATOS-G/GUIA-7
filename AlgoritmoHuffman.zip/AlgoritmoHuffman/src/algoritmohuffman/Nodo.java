package algoritmohuffman;

public class Nodo implements Comparable<Nodo>{

    private Nodo nodoIzquierdo;
    private Nodo nodoDerecho;
    private final int frecuencia;

    public Nodo(int frecuencia) {
        this.frecuencia = frecuencia;
        this.nodoIzquierdo = null;
        this.nodoDerecho = null;
    }

    public Nodo getNodoIzquierdo() {
        return nodoIzquierdo;
    }

    public Nodo getNodoDerecho() {
        return nodoDerecho;
    }

    public int getFrecuencia() {
        return frecuencia;
    }

    public Nodo(Nodo nodoIzquierdo, Nodo nodoDerecho) {
        this.frecuencia = nodoIzquierdo.getFrecuencia() + nodoDerecho.getFrecuencia();
        this.nodoIzquierdo = nodoIzquierdo;
        this.nodoDerecho = nodoDerecho;
    }

    @Override
    public int compareTo(Nodo nodo) {
        return Integer.compare(frecuencia, nodo.getFrecuencia());
    }
}
