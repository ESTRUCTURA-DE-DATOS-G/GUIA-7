package arbolbinario;

import javax.swing.JOptionPane;

public class ArbolBinarioNumeros {

    private NodoNumeros raiz;
    private String preOrden;
    private String postOrden;
    private String inOrden;
    private int alturaArbol;
    private int alturaNodo;

    public ArbolBinarioNumeros() {
        this.raiz = null;
    }

    public void insertarNodo(int valor) {
        if (raiz == null) {
            raiz = new NodoNumeros(valor);
        } else {
            raiz.insertarNumeros(valor);
        }

    }

    public void recorridoPreOrden() {
        preOrden = "";
        PreOrden(raiz);
    }

    //raíz -> hijo izquierdo -> hijo derecho
    private void PreOrden(NodoNumeros nodo) {

        if (nodo == null) {
            return;
        }
        preOrden = preOrden + " " + nodo.getDato();
        PreOrden(nodo.getNodoIzq());
        PreOrden(nodo.getNodoDer());

    }

    public void recorridoInOrden() {
        inOrden = "";
        InOrden(raiz);

    }

    //hijo izquierdo -> raíz -> hijo derecho
    public void InOrden(NodoNumeros nodo) {
        if (nodo == null) {
            return;
        }
        InOrden(nodo.getNodoIzq());
        inOrden = inOrden + " " + nodo.getDato();
        InOrden(nodo.getNodoDer());

    }

    //hijo izquierdo -> hijo derecho -> raíz
    public void recorridoPostOrden() {
        postOrden = "";
        PostOrden(raiz);
    }

    public void PostOrden(NodoNumeros nodo) {
        if (nodo == null) {

        } else {
            PostOrden(nodo.getNodoIzq());
            PostOrden(nodo.getNodoDer());
            postOrden = postOrden + " " + nodo.getDato();
        }
    }

    public boolean eliminar(int valor) {
        // Verificar si el árbol está vacío
        if (raiz == null) {
            return false;
        }

        // Buscar el nodo a eliminar
        NodoNumeros nodoAEliminar = buscarNodo(raiz, valor);

        // Si el nodo no existe en el árbol, retornar false
        if (nodoAEliminar == null) {
            return false;
        }

        // Llamar al método auxiliar para eliminar el nodo
        raiz = eliminarNodo(raiz, valor);
        return true;
    }

    private NodoNumeros eliminarNodo(NodoNumeros nodo, int valor) {
        // Caso base: si el nodo es nulo, retornar null
        if (nodo == null) {
            return null;
        }

        // Si el valor a eliminar es menor que el valor del nodo actual,
        // ir al subárbol izquierdo
        if (valor < nodo.getDato()) {
            nodo.setNodoIzq(eliminarNodo(nodo.getNodoIzq(), valor));
        } // Si el valor a eliminar es mayor que el valor del nodo actual,
        // ir al subárbol derecho
        else if (valor > nodo.getDato()) {
            nodo.setNodoDer(eliminarNodo(nodo.getNodoDer(), valor));
        } // Si el nodo a eliminar tiene dos hijos
        else {
            // Caso 1: el nodo a eliminar es una hoja (no tiene hijos)
            if (nodo.getNodoIzq() == null && nodo.getNodoDer() == null) {
                return null;
            }
            // Caso 2: el nodo a eliminar tiene un solo hijo
            if (nodo.getNodoIzq() == null) {
                return nodo.getNodoDer();
            }
            if (nodo.getNodoDer() == null) {
                return nodo.getNodoIzq();
            }
            // Caso 3: el nodo a eliminar tiene dos hijos
            // Encontrar el sucesor inmediato (el valor más pequeño en el subárbol derecho)
            NodoNumeros sucesor = encontrarSucesor(nodo.getNodoDer());
            // Reemplazar el valor del nodo actual con el valor del sucesor
            nodo.setDato(sucesor.getDato());
            // Eliminar el sucesor
            nodo.setNodoDer(eliminarNodo(nodo.getNodoDer(), sucesor.getDato()));
        }

        return nodo;
    }

    private NodoNumeros encontrarSucesor(NodoNumeros nodo) {
        NodoNumeros actual = nodo;
        // Buscar el nodo más a la izquierda en el subárbol derecho
        while (actual.getNodoIzq() != null) {
            actual = actual.getNodoIzq();
        }
        return actual;
    }


    public boolean buscar(int valor) {
        NodoNumeros nodoEncontrado = buscarNodo(raiz, valor);
        if (nodoEncontrado != null) {
            JOptionPane.showMessageDialog(null, "El valor " + valor + " ha sido encontrado en el árbol.", "Búsqueda Exitosa", JOptionPane.INFORMATION_MESSAGE);
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "El valor " + valor + " no ha sido encontrado en el árbol.", "Búsqueda Fallida", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private NodoNumeros buscarNodo(NodoNumeros nodo, int valor) {
        if (nodo == null || nodo.getDato() == valor) {
            return nodo;
        }

        if (valor < nodo.getDato()) {
            return buscarNodo(nodo.getNodoIzq(), valor);
        } else {
            return buscarNodo(nodo.getNodoDer(), valor);
        }
    }

    public String getPreOrden() {
        return preOrden;
    }

    public String getPostOrden() {
        return postOrden;
    }

    public String getInOrden() {
        return inOrden;
    }

    public int getAlturaArbol() {
        return alturaArbol;
    }

    public int getAlturaNodo() {
        return alturaNodo;
    }

    public NodoNumeros getRaiz() {
        return raiz;
    }

}
