package arbolbinario;

public class NodoNumeros {

    private int dato;
    private NodoNumeros nodoIzq;
    private NodoNumeros nodoDer;

    public int getDato() {
        return dato;
    }

    public NodoNumeros getNodoIzq() {
        return nodoIzq;
    }

    public NodoNumeros getNodoDer() {
        return nodoDer;
    }

    public NodoNumeros() {

    }

    public NodoNumeros(int datoNodo) {
        this.dato = datoNodo;
        nodoIzq = null;
        nodoDer = null;
    }

    public void insertarNumeros(int valor) {

        if (valor <= dato) {
            if (nodoIzq == null) {
                nodoIzq = new NodoNumeros(valor);
            } else {
                nodoIzq.insertarNumeros(valor);
            }
        } else if (valor > dato) {
            if (nodoDer == null) {
                nodoDer = new NodoNumeros(valor);
            } else {
                nodoDer.insertarNumeros(valor);
            }

        }

    }
    
    public int NodosCompletos (NodoNumeros n){
        if (n==null) {
           return 0; 
        }else{
            if (n.getNodoIzq()!=null&&n.getNodoDer()!=null) {
                return NodosCompletos(n.getNodoIzq())+NodosCompletos(n.getNodoDer())+1;
            }
        }
        return 0;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }

    public void setNodoIzq(NodoNumeros nodoIzq) {
        this.nodoIzq = nodoIzq;
    }

    public void setNodoDer(NodoNumeros nodoDer) {
        this.nodoDer = nodoDer;
    }

}
